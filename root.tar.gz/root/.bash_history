history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
dpkg --audit
tail -n 30 /var/log/apt/term.log
nano /etc/default/grub
vim /etc/default/grub
grep GRUB_DISABLE_OS_PROBER /etc/default/grub
dpkg --configure -a
dpkg --audit
apt full-upgrade
reboot
cat /etc/debian_version
dpkg --audit
vim /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
cat /etc/apt/sources.list
clear
apt full-upgrade
reboot
clear
cat /etc/debian_version && lsb_release -a && uname -r && dpkg --audit
clear
apt install -y openssh-server
clear
systemctl enable --now ssh
ls -la /root
tar -tvzf /root/Material_Adicional_TPVMCA.tar.gz 
cd /root/
tar -xzvf Material_Adicional_TPVMCA.tar.gz 
ls -la /root/
mkdir -p /root/.ssh
cp /root/Material_Adicional_TPVMCA/clave_publica.pub /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.shh/authorized_keys
ls -la /root/.ssh/
chmod 600 /root/.ssh/authorized_keys
ls -la /root/.ssh/
vim /etc/ssh/sshd_config
clear
sshd -t
systemctl restart ssh
vim /etc/ssh/sshd_config
clear
grep -E "PermitRootLogin|PubkeyAuthentication/AuthorizedKeysFile/PasswordAuthentication"
grep -E "PermitRootLogin|PubkeyAuthentication/AuthorizedKeysFile/PasswordAuthentication" /etc/ssh/sshd_config
grep -E "PermitRootLogin|PubkeyAuthentication|AuthorizedKeysFile|PasswordAuthentication" /etc/ssh/sshd_config
clear
ip a show enp0s3
clear
apt install -y apache2 php libapache-2-mod-php
clear
ifdown enp0s3
vim /etc/network/interfaces
clear
cat /etc/network/interfaces
systemctl restart networking
ip a show enp0s3
iproute
ip route
vim /etc/network/interfaces
clear
cat /etc/network/interfaces
systemctl restart networking
ip a show enp0s3
ip route
reboot
clear
apt install -y apache2 php libapache-2-mod-php
apt install -y apache2 php libapache2-mod-php
clear
systemctl enable --now apache2
php -v
apache2ctl -M | grep php
clear
cp /root/Material_Adicional_TPVMCA/index.php /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
chown -R www-data:www-data /var/www/html
chmod 644 /var/www/html/index.php /var/www/html/logo.png
rm -f /var/www/html/index.html
ls -la /var/www/html
clear
curl http://localhost/index.php
curl -I http://localhost
curl -I http://localhost/
tail -n 30 /var/log/apache2/error.log
clear
apt install -y php-mysql && systemctl restart apache2
clear
tail -n 5 /var/log/apache2/error.log
php -m
php -m | grep -i mysql
curl -I http://localhost/
tail -n 5 /var/log/apache2/error.log
clear
apt install -y mariadb-server
clear
systemctl enable --now mariadb
systemctl status mariadb
clear
head -30 /root/Material_Adicional_TPVMCA/db.sql
clear
head -30 /root/Material_Adicional_TPVMCA/index.php
clear
mysql < /root/Material_Adicional_TPVMCA/db.sql
clear
mysql -e "SHOW DATABASES;"
mysql -e "USE ingenieria; SHOW TABLES;"
mysql -e "SELECT user,host FROM mysql.user;"
clear
mysql -u lcars -p'NCC1701D' -e "USE ingenieria; SELECT * FROM alumnos LIMIT 5;"
clear
curl -I http://localhost/
curl http://localhost/index.php
clear
ip a
cat /etc/network/interfaces
ls -la /etc/network/interfaces.d/
ping -c 3 192.168.100.200
clear
ip a show enp0s3
ping -c 3 8.8.8.8
ping -c 3 deb.debian.org
poweroff
clear
reboot
clear
lsblk
fdisk -l /dev/sdc
clear
fdisk /dev/sdc
fdisk -l /dev/sdc
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
mkdir -p /www_dir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h /www_dir /backup_dir
cp /root/Material_Adicional_TPVMCA/index.php /root/Material_Adicional_TPVMCA/logo.png /www_dir/
chown -R www-data:www-data /www_di
chown -R www-data:www-data /www_dir
chmod 755 /www_dir
chmod 644 /www_dir/index.php /www_dir/logo.png
ls -la /www_dir
vim /etc/apache2/sites-available/000-default.conf
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
vim /etc/apache2/apache2.conf
grep -A 4 "Directory /www_dir" /etc/apache2/apache2.conf 
clear
apache2ctl configtest
systemctl reload apache2
curl -I http://localhost/logo.png
blkid /dev/sdc1 /dev/sdc2
cp /etc/fstab /etc/fstab.bak
clear
echo "UUID=$(blkid -s UUID -o value /dev/sdc1)  /www_dir     ext4  defaults  0  2" >> /etc/fstab
echo "UUID=$(blkid -s UUID -o value /dev/sdc2)  /backup_dir  ext4  defaults  0  2" >> /etc/fstab
cat /etc/fstab
umount /www_dir /backup_dir
mount -a
systemctl daemon-reload
mount -a
df -h | grep -E "www_dir|backup_dir"
